export enum SYS_ROLE {
    user="user",
    admin="admin",
    superAdmin="superAdmin",
}

export enum GENDER{
    male="male",
    female="female"
}

export enum USER_AGENT{
    local='local',
    google='google'
}

export enum REACTION{
    like,
    love,
    care,
    sad,
    angry
}